package com.example.vicky.todolist.DTO

class ToDoItem(){

    var id : Long = -1
    var toDoId : Long = -1
    var itemName = ""
    var isCompleted = false

}